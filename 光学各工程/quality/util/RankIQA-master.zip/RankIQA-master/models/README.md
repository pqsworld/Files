## The folder to save the trained models
The pre-trained [VGG-16](https://gist.github.com/ksimonyan/211839e770f7b538e2d8#file-readme-md) ImageNet model should be put here to do finetuning.
