
## The code for generating ranking dataset for tid2013 dataset (17 distortions)

Put your original images in pristine_images folder and run the main function.

```
run tid2013_main.m

```




