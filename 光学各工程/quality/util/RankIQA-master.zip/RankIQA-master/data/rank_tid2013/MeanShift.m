function b = MeanShift(img,level)

img = img + level;

b = uint8(img);


end