# Run the main function

```
run distortion_saver.m 
```
